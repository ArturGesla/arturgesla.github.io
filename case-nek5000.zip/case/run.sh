#!/bin/bash

rm *.fld*

#meshing
. mkmsh-pretex
. mkmsh-n2to3

cp mesh.rea r1854a.rea
cp mesh.re2 r1854a.re2

genmap << EOF
r1854a
0.2
EOF


#run
makenek r1854a
nek r1854a


#visu
visnek r1854a
