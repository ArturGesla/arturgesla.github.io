#/bin/bash
rm -r 1* 2* 3* 4* 5* 6* 7* 8* 9*
rm -r constant/poly*
rm *.dat
rm *.csv res* run*
rm -r 0.*
rm cfl
